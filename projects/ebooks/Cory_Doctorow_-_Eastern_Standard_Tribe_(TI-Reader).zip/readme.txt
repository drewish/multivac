Eastern Standard Tribe (for the TI-Reader)
Cory Doctorow
Copyright 2004 Cory Doctorow
doctorow@craphound.com
http://www.craphound.com/est
Tor Books, March 2004
ISBN: 0765307596

Prepared for Texas Instruments' TI-Reader by andrew morton (http://drewish.com) based upon Raja Thiagarajan's HTML version. 

Included in this zip file are versions of EST for the following calculators: TI-89 (small font), TI-92 Plus (large font), and Voyage 200 (large font). I've only been able to test out the Voyage 200 files but believe that the others should be fine. 

The TI-Reader can be found at: http://education.ti.com/us/product/apps/89/reader.html

You'll need the TI-Connect software to install the ebook and reader. It can be found at: http://education.ti.com/us/product/accessory/connectivity/down/download.html